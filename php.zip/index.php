<?php
session_start();
$con = mysqli_connect("localhost","root","","webshop");

if (mysqli_connect_errno())
  {
  print( "Adatbázis kapcsolódási hiba!  " . mysqli_connect_error());
  }
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>doga</title>
</head>
<body>


        <?php
        if(!isset($_SESSION['nev2']))
        {
            
            print("<a href='Bejelentkezes.php'>Bejelentkezés</a>");
            print("<a href='regisztracio.php'>Regisztráció</a>");
        }
        else
        {
            
            print("<button class='legordulogomb'>".$_SESSION['nev2']."</button>");
            print("<a href='#'>Profil</a>");
            print("<a href='Kijelentkezes.php'>Kijelentkezés</a>");

        }
        ?>

        
        
    
</body>

</html>